from django.shortcuts import render
from django.http import HttpResponse
from django.http import Http404

from .models import Pet

def home(requests):
    pets = Pet.objects.all()
    return render(requests, 'home.html', {'pets': pets})

def pet_detail(requests, id):
    try:
        pet = Pet.objects.get(id=id)
    except Pet.DoesNotExist:
        raise Http404('Pet not found')
    return render(requests, 'pet_detail.html', {'pet': pet})
